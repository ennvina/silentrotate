# silentrotate
WoW Classic addon for spell rotations in raid
